# funkin-utau
*"Ready? Set? Sing!"
A repository with the famous game Friday Night Funkin's characters voices, for UTAU!
-------------------
You must credit GenoX and KawaiSprite when using!!, Also if you're using a FANMADE UTAU, credit the original autors of them!

Voices separated in .wav's by: GenoX https://www.youtube.com/c/GenoXLOID

Whitty UTAU by: AjtheYandere https://www.youtube.com/c/AjtheYandere

You want the Monster UTAU? Check this out!: https://youtu.be/Oje2IQ4Hz8k Credits to Halfne Cross

You can also use some midi editor for the voices, but i'm not teaching you how to do that lol, if you have any problems go to the Wiki tab, Issues tab or talk to me in Discord: GenoX#2279

Original Creators of the FANMADE UTAUs
-------------------
-Carol-bbpanzu-

-Whitty-Sock.clip-

-ExGF-xylobeta-

-Hex-YingYang48-

-Annie-atsuover-

send a lot of love to these creators!

IMPORTANT NOTES:
---------------------

Some VoiceBanks like Pico and Monster needs to be lowed 2 octaves so they can sound normal, for do that follow this guide:

>1 Go to the "Edit" menu (In UTAU, ofc)

>2 Select "Move Region by Number"

>3 The next you need to know about the piano roll, but you can put the number without knowing that. Expect getting it wrong) 

>4 If the notes of your midi/UST project are between C3 and C4, put -24 on the box, but if the notes are between C2 and C3, put -12

>5 Press OK

>The notes are now octaves lower! press play for see if Pico and Monster now sounds good!

With the same guide of before you can also do with male voices like Whitty
>Whitty uses 1 octave lower, so move -12

Skid and Pump have the same voice provideer but different between South and Spookeez
>so i put Spookez as Skid and South as Pump

...

..

.

Oh you read all of this?? Nice! Go ahead and download from the Source Code
